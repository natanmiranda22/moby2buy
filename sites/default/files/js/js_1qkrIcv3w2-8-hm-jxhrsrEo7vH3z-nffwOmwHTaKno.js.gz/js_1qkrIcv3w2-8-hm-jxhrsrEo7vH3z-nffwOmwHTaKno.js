/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.moby2buy = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
